package testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class D11Project {
	WebDriver driver;

	@BeforeTest
	public void beforeTest() {
		driver = new ChromeDriver();
	}

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://sampleapp.tricentis.com/101/app.php");
	}

	@BeforeMethod
	public void beforeMethod() throws InterruptedException {
		Thread.sleep(2000);
	}

	@Test
	public void AutoMobile() throws InterruptedException {
		WebElement autoMobile = driver
				.findElement(By.xpath("//div[@class='main-navigation']//a[@id='nav_automobile']"));
		autoMobile.click();

		// Enter Vehicle data
		WebElement Make = driver.findElement(By.xpath("//select[@id='make']"));

		Select option = new Select(Make);
		option.selectByValue("BMW");

		WebElement enginePer = driver.findElement(By.xpath("//input[@id='engineperformance']"));
		enginePer.sendKeys("2");

		WebElement dateMan = driver.findElement(By.xpath("//input[@id='dateofmanufacture']"));
		dateMan.sendKeys("06/06/2025");

		WebElement noSeat = driver.findElement(By.xpath("//select[@id='numberofseats']"));
		Select option1 = new Select(noSeat);
		option1.selectByValue("2");

		WebElement fualType = driver.findElement(By.xpath("//select[@id='fuel']"));
		Select option2 = new Select(fualType);
		option2.selectByValue("Diesel");

		WebElement listPrice = driver.findElement(By.xpath("//input[@id='listprice']"));
		listPrice.sendKeys("50000");

		WebElement licenseNo = driver.findElement(By.xpath("//input[@id='licenseplatenumber']"));
		licenseNo.sendKeys("MH7263");

		WebElement annualMil = driver.findElement(By.xpath("//input[@id='annualmileage']"));
		annualMil.sendKeys("900");

		WebElement next = driver.findElement(By.xpath("//button[@id='nextenterinsurantdata']"));
		next.click();

		// Insurant Data

		WebElement firstName = driver.findElement(By.xpath("//input[@id='firstname']"));
		firstName.sendKeys("Sakshi");

		WebElement lastName = driver.findElement(By.xpath("//input[@id='lastname']"));
		lastName.sendKeys("Shinde");

		WebElement DOB = driver.findElement(By.xpath("//input[@id='birthdate']"));
		DOB.sendKeys("10/06/2003");

		Thread.sleep(1000);
		WebElement gender = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[4]/p/label[2]"));
		if (gender.isSelected() == false) {
			gender.click();
		}

		WebElement address = driver.findElement(By.xpath("//input[@id='streetaddress']"));
		address.sendKeys("Old Sagnvi, Pune");

		WebElement country = driver.findElement(By.xpath("//select[@id='country']"));
		Select option3 = new Select(country);
		option3.selectByValue("India");

		WebElement pin = driver.findElement(By.xpath("//input[@id='zipcode']"));
		pin.sendKeys("411027");

		WebElement city = driver.findElement(By.xpath("//input[@id='city']"));
		city.sendKeys("Pune");

		WebElement occupation = driver.findElement(By.xpath("//select[@id='occupation']"));
		Select option4 = new Select(occupation);
		option4.selectByValue("Unemployed");

		WebElement hobbies = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[10]/p/label[4]/span"));
		if (hobbies.isSelected() == false) {
			hobbies.click();
		}

		WebElement website = driver.findElement(By.xpath("//input[@id='website']"));
		website.sendKeys("www.website.com");

		// picture

		WebElement next1 = driver.findElement(By.xpath("//button[@id='nextenterproductdata']"));
		next1.click();

		// Product Data

		WebElement startDate = driver.findElement(By.xpath("//input[@id='startdate']"));
		startDate.sendKeys("10/06/2025");

		WebElement insuranceSum = driver.findElement(By.xpath("//*[@id=\"insurancesum\"]"));
		Select option5 = new Select(insuranceSum);
		option5.selectByValue("3000000");

		WebElement meritRate = driver.findElement(By.xpath("//*[@id=\"meritrating\"]"));
		Select option6 = new Select(meritRate);
		option6.selectByValue("Super Bonus");

		WebElement damageIns = driver.findElement(By.xpath("//*[@id=\"damageinsurance\"]"));
		Select option7 = new Select(damageIns);
		option7.selectByValue("Full Coverage");

		WebElement optionalPro = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[3]/div[5]/p/label[2]"));
		if (optionalPro.isSelected() == false) {
			optionalPro.click();
		}

		WebElement courtesyCar = driver.findElement(By.xpath("//*[@id=\"courtesycar\"]"));
		Select option8 = new Select(courtesyCar);
		option8.selectByValue("Yes");

		WebElement next2 = driver.findElement(By.xpath("//*[@id=\"nextselectpriceoption\"]"));
		next2.click();

		// Select Price Option
		WebElement selectOp = driver.findElement(By.xpath("//*[@id=\"priceTable\"]/tfoot/tr/th[2]/label[4]/span"));
		if (selectOp.isSelected() == false) {
			selectOp.click();
		}

		WebElement next3 = driver.findElement(By.xpath("//*[@id=\"nextsendquote\"]"));
		next3.click();

		// Send Quote

		WebElement email = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		email.sendKeys("sakshishinde209@gmail.com");

		WebElement phone = driver.findElement(By.xpath("//*[@id=\"phone\"]"));
		phone.sendKeys("9359272469");

		WebElement username = driver.findElement(By.xpath("//*[@id=\"username\"]"));
		username.sendKeys("sakshi12");

		WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		password.sendKeys("123Sakshi");

		WebElement confirmPassword = driver.findElement(By.xpath("//*[@id=\"confirmpassword\"]"));
		confirmPassword.sendKeys("123Sakshi");

		WebElement comment = driver.findElement(By.xpath("//*[@id=\"Comments\"]"));
		comment.sendKeys("This is Sakshi Shinde");

		WebElement send = driver.findElement(By.xpath("//*[@id=\"sendemail\"]"));
		send.click();

		Thread.sleep(2000);
		WebElement ok = driver.findElement(By.xpath("/html/body/div[4]/div[7]/div/button"));
		ok.click();

	}

//--------------------------------------------------------------------------------------------------
	@Test
	public void Truck() throws InterruptedException {
		WebElement truck = driver.findElement(By.xpath("//div[@class='main-navigation']//a[@id='nav_truck']"));
		truck.click();

		// Vehicle Data
		WebElement Make1 = driver.findElement(By.xpath("//select[@id='make']"));

		Select option9 = new Select(Make1);
		option9.selectByValue("Audi");

		WebElement enginePer1 = driver.findElement(By.xpath("//input[@id='engineperformance']"));
		enginePer1.sendKeys("3");

		WebElement dateMan1 = driver.findElement(By.xpath("//input[@id='dateofmanufacture']"));
		dateMan1.sendKeys("06/06/2024");

		WebElement noSeat1 = driver.findElement(By.xpath("//select[@id='numberofseats']"));
		Select option10 = new Select(noSeat1);
		option10.selectByValue("2");

		WebElement fualType1 = driver.findElement(By.xpath("//select[@id='fuel']"));
		Select option11 = new Select(fualType1);
		option11.selectByValue("Petrol");

		WebElement payLoad = driver.findElement(By.xpath("//input[@id='payload']"));
		payLoad.sendKeys("500");

		WebElement totalWeight = driver.findElement(By.xpath("//input[@id='totalweight']"));
		totalWeight.sendKeys("963");

		WebElement listPrice1 = driver.findElement(By.xpath("//input[@id='listprice']"));
		listPrice1.sendKeys("40000");

		WebElement licenseNo1 = driver.findElement(By.xpath("//*[@id=\"licenseplatenumber\"]"));
		licenseNo1.sendKeys("456263");

		WebElement annualMil1 = driver.findElement(By.xpath("//*[@id=\"annualmileage\"]"));
		annualMil1.sendKeys("900");

		WebElement next4 = driver.findElement(By.xpath("//button[@id='nextenterinsurantdata']"));
		next4.click();

		// Insurant Data

		WebElement firstName1 = driver.findElement(By.xpath("//input[@id='firstname']"));
		firstName1.sendKeys("Rutuja");

		WebElement lastName1 = driver.findElement(By.xpath("//input[@id='lastname']"));
		lastName1.sendKeys("Laver");

		WebElement DOB1 = driver.findElement(By.xpath("//input[@id='birthdate']"));
		DOB1.sendKeys("10/06/2000");

		Thread.sleep(1000);

		WebElement gender1 = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[4]/p/label[2]/span"));
		if (gender1.isSelected() == false) {
			gender1.click();
		}

		WebElement address1 = driver.findElement(By.xpath("//input[@id='streetaddress']"));
		address1.sendKeys("Sagnvi, Pune");

		WebElement country1 = driver.findElement(By.xpath("//select[@id='country']"));
		Select option12 = new Select(country1);
		option12.selectByValue("India");

		WebElement pin1 = driver.findElement(By.xpath("//input[@id='zipcode']"));
		pin1.sendKeys("411027");

		WebElement city1 = driver.findElement(By.xpath("//input[@id='city']"));
		city1.sendKeys("Pune");

		WebElement occupation1 = driver.findElement(By.xpath("//*[@id=\"occupation\"]"));
		Select option13 = new Select(occupation1);
		option13.selectByValue("Employee");

		WebElement hobbies1 = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[10]/p/label[3]/span"));
		if (hobbies1.isSelected() == false) {
			hobbies1.click();
		}

		WebElement website1 = driver.findElement(By.xpath("//input[@id='website']"));
		website1.sendKeys("www.website.com");

		// picture

		WebElement next5 = driver.findElement(By.xpath("//button[@id='nextenterproductdata']"));
		next5.click();

		// Product Data
		WebElement startDate1 = driver.findElement(By.xpath("//*[@id=\"startdate\"]"));
		startDate1.sendKeys("11/04/2025");

		WebElement insuranceSum1 = driver.findElement(By.xpath("//*[@id=\"insurancesum\"]"));
		Select option14 = new Select(insuranceSum1);
		option14.selectByValue("5000000");

		WebElement damageIns1 = driver.findElement(By.xpath("//*[@id=\"damageinsurance\"]"));
		Select option16 = new Select(damageIns1);
		option16.selectByValue("Partial Coverage");

		WebElement optionalPro1 = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[3]/div[4]/p/label[1]/span"));
		if (optionalPro1.isSelected() == false) {
			optionalPro1.click();
		}

		Thread.sleep(4000);
		WebElement next6 = driver.findElement(By.xpath("//button[@id='nextselectpriceoption']"));
		next6.click();

		// Price Option

		WebElement selectOp1 = driver.findElement(By.xpath("//*[@id=\"priceTable\"]/tfoot/tr/th[2]/label[4]/span"));
		if (selectOp1.isSelected() == false) {
			selectOp1.click();
		}

		WebElement net = driver.findElement(By.xpath("//*[@id=\"nextsendquote\"]"));
		net.click();

		// Send Quote

		WebElement email1 = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		email1.sendKeys("Rutushinde209@gmail.com");

		WebElement phone1 = driver.findElement(By.xpath("//*[@id=\"phone\"]"));
		phone1.sendKeys("9359272469");

		WebElement username1 = driver.findElement(By.xpath("//*[@id=\"username\"]"));
		username1.sendKeys("Rutuja12");

		WebElement password1 = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		password1.sendKeys("123Rutu");

		WebElement confirmPassword1 = driver.findElement(By.xpath("//*[@id=\"confirmpassword\"]"));
		confirmPassword1.sendKeys("123Rutu");

		WebElement comment1 = driver.findElement(By.xpath("//*[@id=\"Comments\"]"));
		comment1.sendKeys("This is Rutuja");

		WebElement send1 = driver.findElement(By.xpath("//*[@id=\"sendemail\"]"));
		send1.click();

		Thread.sleep(2000);
		WebElement ok1 = driver.findElement(By.xpath("/html/body/div[4]/div[7]/div/button"));
		ok1.click();

	}
//--------------------------------------------------------------------------------------------------
	@Test
	public void Motorcycle() throws InterruptedException {
		WebElement Motorcycle = driver
				.findElement(By.xpath("//div[@class='main-navigation']//a[@id='nav_motorcycle']"));
		Motorcycle.click();

		// Vehicle Data

		WebElement Make2 = driver.findElement(By.xpath("//*[@id=\"make\"]"));
		Select opt = new Select(Make2);
		opt.selectByValue("Toyota");

		WebElement model = driver.findElement(By.xpath("//select[@id='model']"));
		model.sendKeys("Moped");

		WebElement cylinder = driver.findElement(By.xpath("//input[@id='cylindercapacity']"));
		cylinder.sendKeys("1242");

		WebElement engper = driver.findElement(By.xpath("//input[@id='engineperformance']"));
		engper.sendKeys("241");

		WebElement dateM = driver.findElement(By.xpath("//input[@id='dateofmanufacture']"));
		dateM.sendKeys("09/03/2021");

		WebElement noSe = driver.findElement(By.xpath("//select[@id='numberofseatsmotorcycle']"));
		noSe.sendKeys("3");

		WebElement listP = driver.findElement(By.xpath("//input[@id='listprice']"));
		listP.sendKeys("45000");

		WebElement annMil = driver.findElement(By.xpath("//input[@id='annualmileage']"));
		annMil.sendKeys("800");

		WebElement ne = driver.findElement(By.xpath("//button[@id='nextenterinsurantdata']"));
		ne.click();

		// Insurant Data

		WebElement firstName2 = driver.findElement(By.xpath("//input[@id='firstname']"));
		firstName2.sendKeys("Suhas");

		WebElement lastName2 = driver.findElement(By.xpath("//input[@id='lastname']"));
		lastName2.sendKeys("Sawant");

		WebElement DOB2 = driver.findElement(By.xpath("//input[@id='birthdate']"));
		DOB2.sendKeys("10/06/1972");

		Thread.sleep(1000);

		WebElement gender2 = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[4]/p/label[1]/span"));
		if (gender2.isSelected() == false) {
			gender2.click();
		}

		WebElement address2 = driver.findElement(By.xpath("//input[@id='streetaddress']"));
		address2.sendKeys("Satara");

		WebElement country2 = driver.findElement(By.xpath("//select[@id='country']"));
		Select opt1 = new Select(country2);
		opt1.selectByValue("India");

		WebElement pin2 = driver.findElement(By.xpath("//input[@id='zipcode']"));
		pin2.sendKeys("432027");

		WebElement city2 = driver.findElement(By.xpath("//input[@id='city']"));
		city2.sendKeys("Wai");

		WebElement occupation2 = driver.findElement(By.xpath("//*[@id=\"occupation\"]"));
		Select opt3 = new Select(occupation2);
		opt3.selectByValue("Farmer");

		WebElement hobbies2 = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[10]/p/label[3]/span"));
		if (hobbies2.isSelected() == false) {
			hobbies2.click();
		}

		WebElement website2 = driver.findElement(By.xpath("//input[@id='website']"));
		website2.sendKeys("www.website.com");

		// picture

		WebElement ne1 = driver.findElement(By.xpath("//button[@id='nextenterproductdata']"));
		ne1.click();

		// Product Data

		WebElement startDate2 = driver.findElement(By.xpath("//*[@id=\"startdate\"]"));
		startDate2.sendKeys("11/27/2025");

		WebElement insuranceSum2 = driver.findElement(By.xpath("//*[@id=\"insurancesum\"]"));
		Select opt4 = new Select(insuranceSum2);
		opt4.selectByValue("7000000");

		WebElement damageIns2 = driver.findElement(By.xpath("//*[@id=\"damageinsurance\"]"));
		Select opt6 = new Select(damageIns2);
		opt6.selectByValue("No Coverage");

		WebElement optionalPro2 = driver
				.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[3]/div[4]/p/label[1]/span"));
		if (optionalPro2.isSelected() == false) {
			optionalPro2.click();
		}

		Thread.sleep(4000);
		WebElement ne2 = driver.findElement(By.xpath("//button[@id='nextselectpriceoption']"));
		ne2.click();

		// Price Option

		WebElement selectOp2 = driver.findElement(By.xpath("//*[@id=\"priceTable\"]/tfoot/tr/th[2]/label[4]/span"));
		if (selectOp2.isSelected() == false) {
			selectOp2.click();
		}

		WebElement net1 = driver.findElement(By.xpath("//*[@id=\"nextsendquote\"]"));
		net1.click();

		// Send Quote

		WebElement email2 = driver.findElement(By.xpath("//*[@id=\"email\"]"));
		email2.sendKeys("Suhas209@gmail.com");

		WebElement phone2 = driver.findElement(By.xpath("//*[@id=\"phone\"]"));
		phone2.sendKeys("9359272469");

		WebElement username2 = driver.findElement(By.xpath("//*[@id=\"username\"]"));
		username2.sendKeys("Suhas2");

		WebElement password2 = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		password2.sendKeys("Shinde323");

		WebElement confirmPassword2 = driver.findElement(By.xpath("//*[@id=\"confirmpassword\"]"));
		confirmPassword2.sendKeys("Shinde323");

		WebElement comment2 = driver.findElement(By.xpath("//*[@id=\"Comments\"]"));
		comment2.sendKeys("This is Rutuja");

		WebElement send2 = driver.findElement(By.xpath("//*[@id=\"sendemail\"]"));
		send2.click();

		Thread.sleep(2000);
		WebElement ok2 = driver.findElement(By.xpath("/html/body/div[4]/div[7]/div/button"));
		ok2.click();

	}
//--------------------------------------------------------------------------------------------------------
	@Test
	public void Camper() throws InterruptedException {
		WebElement Camper= driver.findElement(By.xpath("//div[@class='main-navigation']//a[@id='nav_camper']"));
		Camper.click();  
		
		//Vehicle Data
		
		WebElement Make3= driver.findElement(By.xpath("//*[@id=\"make\"]"));				
		Select opt5 =new Select(Make3);
		opt5.selectByValue("Porsche");
		
		WebElement eng= driver.findElement(By.xpath("//*[@id=\"engineperformance\"]"));
		eng.sendKeys("12");
		
		WebElement dateM1= driver.findElement(By.xpath("//input[@id='dateofmanufacture']"));
		dateM1.sendKeys("01/03/2021");
		
		WebElement noSe1= driver.findElement(By.xpath("//select[@id='numberofseats']"));
		noSe1.sendKeys("4");
		
		WebElement righthand=driver.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[1]/div[5]/p/label[1]/span"));
			if(righthand.isSelected()==false) {
				righthand.click();
				
		WebElement fuel= driver.findElement(By.xpath("//select[@id='fuel']"));
		fuel.sendKeys("Diesel");
						
		WebElement payl= driver.findElement(By.xpath("//input[@id='payload']"));
		payl.sendKeys("124");
				
		WebElement totalw= driver.findElement(By.xpath("//input[@id='totalweight']"));
		totalw.sendKeys("241");
				
		WebElement listP1= driver.findElement(By.xpath("//input[@id='listprice']"));
		listP1.sendKeys("35000");
		
		WebElement lic= driver.findElement(By.xpath("//*[@id=\"licenseplatenumber\"]"));
		lic.sendKeys("728372");
						
		WebElement annMi= driver.findElement(By.xpath("//input[@id='annualmileage']"));
		annMi.sendKeys("1000");
				
		WebElement nee= driver.findElement(By.xpath("//*[@id=\"nextenterinsurantdata\"]"));
		nee.click();
		
		//Insurant Data
		
		WebElement firstName3= driver.findElement(By.xpath("//input[@id='firstname']"));
	    firstName3.sendKeys("Suhas");
				
		WebElement lastName3= driver.findElement(By.xpath("//input[@id='lastname']"));
		lastName3.sendKeys("Sawant");
				
		WebElement DOB3= driver.findElement(By.xpath("//input[@id='birthdate']"));
		DOB3.sendKeys("10/06/1972");
				
		Thread.sleep(1000);
				
	    WebElement gender3=driver.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[4]/p/label[1]/span"));
		if(gender3.isSelected()==false) {
					gender3.click();
				}
				
		WebElement address3= driver.findElement(By.xpath("//input[@id='streetaddress']"));
		address3.sendKeys("MedankarWadi");
				
		WebElement country3= driver.findElement(By.xpath("//select[@id='country']"));
		Select optt =new Select(country3);
		optt.selectByValue("India");
				
		WebElement pin3= driver.findElement(By.xpath("//input[@id='zipcode']"));
		pin3.sendKeys("672027");
				 
		WebElement city3= driver.findElement(By.xpath("//input[@id='city']"));
		city3.sendKeys("Chakan");
				
		WebElement occupation3= driver.findElement(By.xpath("//*[@id=\"occupation\"]"));
		Select optt1 =new Select(occupation3);
		optt1.selectByValue("Farmer");
				
		WebElement hobbies3= driver.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[10]/p/label[3]/span"));
		if(hobbies3.isSelected()==false) {
					hobbies3.click();
				}
				
		WebElement website3= driver.findElement(By.xpath("//input[@id='website']"));
		website3.sendKeys("www.website.com");
				
		//picture
				
		WebElement n= driver.findElement(By.xpath("//button[@id='nextenterproductdata']"));
		n.click();
		
		//Product Data
		
		WebElement startDate3= driver.findElement(By.xpath("//*[@id=\"startdate\"]"));
		startDate3.sendKeys("11/27/2025");
		
		WebElement insuranceSum3= driver.findElement(By.xpath("//*[@id=\"insurancesum\"]"));
		Select optt2 =new Select(insuranceSum3);
		optt2.selectByValue("7000000");
		
		WebElement damageIns3= driver.findElement(By.xpath("//*[@id=\"damageinsurance\"]"));
		Select optt3 =new Select(damageIns3);
		optt3.selectByValue("No Coverage");
		
		WebElement optionalPro3= driver.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[3]/div[4]/p/label[1]/span"));
		if(optionalPro3.isSelected()==false) {
			optionalPro3.click();
		}
		
		Thread.sleep(4000);
		WebElement ne3= driver.findElement(By.xpath("//button[@id='nextselectpriceoption']"));
		ne3.click();
		
		//Price Option
	
		WebElement selectOp3= driver.findElement(By.xpath("//*[@id=\"priceTable\"]/tfoot/tr/th[2]/label[4]/span"));
		if(selectOp3.isSelected()==false) {
			selectOp3.click();
		}
		
		WebElement net2= driver.findElement(By.xpath("//*[@id=\"nextsendquote\"]"));
		net2.click();	
		
		// Send Quote
		
		WebElement email3= driver.findElement(By.xpath("//*[@id=\"email\"]"));
		email3.sendKeys("Darshan87@gmail.com");
				
		WebElement phone3= driver.findElement(By.xpath("//*[@id=\"phone\"]"));
		phone3.sendKeys("9359272469");
				
		WebElement username3= driver.findElement(By.xpath("//*[@id=\"username\"]"));
		username3.sendKeys("Darshan2");
				
		WebElement password3= driver.findElement(By.xpath("//*[@id=\"password\"]"));
		password3.sendKeys("Darshan4323");
				
		WebElement confirmPassword3= driver.findElement(By.xpath("//*[@id=\"confirmpassword\"]"));
		confirmPassword3.sendKeys("Darshan4323");
				
		WebElement comment3= driver.findElement(By.xpath("//*[@id=\"Comments\"]"));
		comment3.sendKeys("Hello");
				
		WebElement send3= driver.findElement(By.xpath("//*[@id=\"sendemail\"]"));
		send3.click();
				
		Thread.sleep(2000);
		WebElement ok3= driver.findElement(By.xpath("/html/body/div[4]/div[7]/div/button"));
		ok3.click();	
		
			}
	}

	@AfterMethod
	public void afterMethod() {

	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}

	@AfterTest
	public void afterTest() {
	}

}
